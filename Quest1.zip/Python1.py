age = 21
cost_of_lunch = 25.78
having_fun = True
your_name = "Dan"

print(age)
print(cost_of_lunch)
print(having_fun)
print(your_name)
print("----------------------------")

x = 10
y = 5
print("result of " + str(x) + " + " + str(y) + ": " + str(x + y))